def my_list(start, end, step):
    return list(range(start, end, step))
result_list = my_list(1, 10, 2)
print(result_list)